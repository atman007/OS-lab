clear

echo 'Enter the number'
read n

i=2
choice=1

while [ $i \< $n ]
do
	x=` expr $n \% $i `
	i=` expr $i + 1 `

	if [ $x = 0 ]
	then
		choice=0
	fi
done

if [ $choice = 1 ]
then
	echo ' it is a prime num'

else
	echo 'it is a composite num'

