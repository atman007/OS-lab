echo Enter the filename
read file

w=`cat $file | wc -w`

echo $file is $w

