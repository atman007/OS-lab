clear

echo " Enter a string"
read str

echo $str > str.txt

len= `echo $str | wc -c`
len= ` expr $len -1 `

s=0 
i=1

while [ $i -lt $len ]
do
	if ["str" = " "] 
	then
	s = ` expr $s + 1 ` 
	fi

	i = ` expr $i + 1 `
done
