clear

echo Enter the filename
read file

c=`cat $file | wc -c`
l=`grep -c "." $file`

echo Number of lines in $file is $l
