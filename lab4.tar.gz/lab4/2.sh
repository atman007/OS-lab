
echo ' enter the string '
read str

if grep -q $str text.txt
then 
	echo 'string found'

else
	echo ' not found'

fi

