clear
b=1

while [ $b = 1 ]
do
	echo 'enter a number'
	read a 

	if [ $a = exit ]
	then
		b=0
	elif [ $a -gt 50 ]
	then
		echo 'please input number less than 50'		
	
	elif [ $a -lt 50 ]
	then	
		echo 'square:'	
		echo `expr $a \* $a`
	fi
done

