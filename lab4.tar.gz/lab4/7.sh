clear

if [ $3 = y ]
then
$chmod $2 $1

else
echo ' Mission failed '

