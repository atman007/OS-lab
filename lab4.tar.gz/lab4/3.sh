clear

echo 'input the number to find a sum from 0 till that number'
read n

m=` expr $n + 1 `
o=` expr $n \* $m `
s=` expr $o \/ 2 `

echo $s
