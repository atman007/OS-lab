echo "Enter Basic Salary: "
read b

hra=0

if [ $b -gt 1500 ]
then
hra=500

else
hra=`expr $b \* 10 / 100`
fi

gs=`expr $b + $hra`

echo "Gross Salary is: Rs.$gs"
echo "Basic: Rs.$b"
echo "HRA: Rs.$hra"

