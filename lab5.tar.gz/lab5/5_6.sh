clear

i=0
sum=0

echo ' you want sum till '
echo $1

while [ $i -lt $1 ]
do
	sum=` expr $i + $sum `
	i=` expr $i + 1 `
done

if [ $sum -lt 50 ]
then 
	echo $sum
else
	echo ' sum exceeding 50'
fi 
