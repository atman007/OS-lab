clear

echo $1 | rev
echo $2 | rev
echo $3 | rev
echo $4 | rev
echo $5 | rev
echo $6 | rev
echo $7 | rev
echo $8 | rev
echo $9 | rev
echo $10 | rev
