clear

if find $1
then 
	cat $1 >> $2
fi
