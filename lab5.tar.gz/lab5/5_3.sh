clear

i=0

while [ $i -lt $1 ]
do
	echo $2
	i=` expr $i + 1 ` 
done
