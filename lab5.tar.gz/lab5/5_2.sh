clear

echo ' enter a string'
read str

str1=` expr $str | rev `

echo $str1

if [ $str = $str1 ]
then
	echo ' the string is a palindrome '

else
	echo ' the string is normal '
fi    
