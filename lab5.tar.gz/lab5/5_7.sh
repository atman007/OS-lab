clear

echo ' input the wild card character'
read alphabet

echo ' list of files with details is as under '
ls -l $alphabet*

