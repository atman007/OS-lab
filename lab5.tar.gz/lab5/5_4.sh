find . -type f | xargs ls -lS | head -n 5
